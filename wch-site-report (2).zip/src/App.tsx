import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { CreateReport } from './components/CreateReport';
import { ViewReport } from './components/ViewReport';
import { Login } from './components/Login';

import { Tasks } from './components/Tasks';

// Wrap app inside AuthProvider
export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<RequireAuth><Layout /></RequireAuth>}>
            <Route index element={<Dashboard />} />
            <Route path="reports/new" element={<RequireRole role={['admin']}><CreateReport /></RequireRole>} />
            <Route path="reports/:id" element={<ViewReport />} />
            <Route path="tasks" element={<RequireRole role={['admin', 'manager']}><Tasks /></RequireRole>} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  
  if (loading) return null;
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

function RequireRole({ children, role }: { children: React.ReactNode, role: string[] }) {
  const { user, loading } = useAuth();
  
  if (loading) return null;
  if (!user || !role.includes(user.role)) {
    return <Navigate to="/" replace />;
  }
  return <>{children}</>;
}
