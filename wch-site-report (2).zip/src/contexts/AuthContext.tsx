import React, { createContext, useContext, useEffect, useState } from 'react';

export type UserRole = 'admin' | 'manager';

export interface AppUser {
  uid: string;
  email: string | null;
  role: UserRole;
  name: string;
}

interface AuthContextType {
  user: AppUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<void>;
  adminResetPassword: (userEmail: string, newPassword: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const VALID_USERS = [
  { email: 'rayyan@wch.local', password: 'password123', name: 'Rayyan', role: 'admin' as UserRole, uid: 'u1' },
  { email: 'sufyan@wch.local', password: 'password123', name: 'Sir Sufyan', role: 'manager' as UserRole, uid: 'u2' },
  { email: 'ghani@wch.local', password: 'password123', name: 'Sir Ghani', role: 'manager' as UserRole, uid: 'u3' },
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem('wch_app_user');
    if (saved) {
      setUser(JSON.parse(saved));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    const lowercaseEmail = email.toLowerCase();
    const storedPasswordsStr = localStorage.getItem('wch_custom_passwords');
    const storedPasswords = storedPasswordsStr ? JSON.parse(storedPasswordsStr) : {};
    
    const matchedUser = VALID_USERS.find(u => u.email === lowercaseEmail);
    if (!matchedUser) {
      throw new Error('Not authorized. Email is not in the allowed users list.');
    }

    const currentPassword = storedPasswords[lowercaseEmail] || matchedUser.password;

    if (currentPassword === password) {
      const appUser: AppUser = { uid: matchedUser.uid, email: matchedUser.email, role: matchedUser.role, name: matchedUser.name };
      setUser(appUser);
      localStorage.setItem('wch_app_user', JSON.stringify(appUser));
    } else {
      throw new Error('Invalid credentials');
    }
  };

  const changePassword = async (oldPassword: string, newPassword: string) => {
    if (!user || (!user.email)) throw new Error('Not authenticated');
    
    // verify old password
    const lowercaseEmail = user.email.toLowerCase();
    const storedPasswordsStr = localStorage.getItem('wch_custom_passwords');
    const storedPasswords = storedPasswordsStr ? JSON.parse(storedPasswordsStr) : {};
    
    const matchedUser = VALID_USERS.find(u => u.email === lowercaseEmail);
    const currentPassword = storedPasswords[lowercaseEmail] || matchedUser?.password;

    if (currentPassword !== oldPassword) {
      throw new Error('Incorrect current password.');
    }

    // save new password
    storedPasswords[lowercaseEmail] = newPassword;
    localStorage.setItem('wch_custom_passwords', JSON.stringify(storedPasswords));
  };

  const adminResetPassword = async (userEmail: string, newPassword: string) => {
    if (!user || user.role !== 'admin') throw new Error('Not authorized to reset passwords.');

    const lowercaseEmail = userEmail.toLowerCase();
    const storedPasswordsStr = localStorage.getItem('wch_custom_passwords');
    const storedPasswords = storedPasswordsStr ? JSON.parse(storedPasswordsStr) : {};
    
    const matchedUser = VALID_USERS.find(u => u.email === lowercaseEmail);
    if (!matchedUser) {
      throw new Error('User not found.');
    }

    storedPasswords[lowercaseEmail] = newPassword;
    localStorage.setItem('wch_custom_passwords', JSON.stringify(storedPasswords));
  };

  const logout = async () => {
    setUser(null);
    localStorage.removeItem('wch_app_user');
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, changePassword, adminResetPassword, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
