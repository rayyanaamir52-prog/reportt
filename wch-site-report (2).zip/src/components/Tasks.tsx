import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { format } from 'date-fns';
import { Loader2, Plus, Briefcase, ListTodo, CheckCircle2, Circle, Trash2, AlertCircle } from 'lucide-react';

export function Tasks() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [duty, setDuty] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'tasks'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      console.error(error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!duty.trim()) return;
    
    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'tasks'), {
        description: duty,
        assignedBy: user?.name || 'Unknown',
        assignedByUid: user?.uid,
        status: 'pending',
        targetDate: dueDate || null,
        createdAt: serverTimestamp()
      });
      setDuty('');
      setDueDate('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'tasks');
      alert('Failed to assign duty.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleTaskStatus = async (taskId: string, currentStatus: string) => {
    if (user?.role !== 'admin') return; // Only Rayyan can mark tasks as done
    try {
      const taskRef = doc(db, 'tasks', taskId);
      await updateDoc(taskRef, {
        status: currentStatus === 'pending' ? 'done' : 'pending',
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating task:', error);
      alert('Failed to update task status.');
    }
  };

  const confirmDeleteAction = async () => {
    if (!taskToDelete) return;
    
    try {
      await deleteDoc(doc(db, 'tasks', taskToDelete));
      setTaskToDelete(null);
    } catch (error) {
      console.error('Error deleting task:', error);
      alert('Failed to delete duty.');
    }
  };

  const cancelDelete = () => {
    setTaskToDelete(null);
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto w-full">
      {user?.role === 'manager' && (
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Assign Duty</h2>
            <p className="text-xs text-slate-500">Add a new task for Rayyan</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea
            value={duty}
            onChange={(e) => setDuty(e.target.value)}
            required
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all sm:text-sm min-h-[120px] resize-y"
            placeholder="Type duty or task details here..."
          />
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex items-center gap-2">
              <label htmlFor="dueDate" className="text-sm font-medium text-slate-700 whitespace-nowrap">Target Date (Optional):</label>
              <input
                type="date"
                id="dueDate"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm text-slate-700"
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting || !duty.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2.5 rounded-lg transition-colors flex items-center gap-2 shadow-sm disabled:opacity-70 disabled:cursor-not-allowed w-full sm:w-auto justify-center"
            >
              {isSubmitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Assigning...</> : <><Plus className="w-4 h-4" /> Assign Duty</>}
            </button>
          </div>
        </form>
      </div>
      )}

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
          <ListTodo className="w-4 h-4 text-slate-500" /> Recent Duties
        </h3>
        
        {loading ? (
          <div className="flex justify-center p-8">
            <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
          </div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm">
            No duties assigned yet.
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map(task => (
              <div 
                key={task.id} 
                className={`p-4 border rounded-lg transition-colors ${
                  task.status === 'done' 
                    ? 'bg-green-50 border-green-100' 
                    : 'bg-slate-50 border-slate-100'
                }`}
              >
                <div className="flex gap-4">
                  {user?.role === 'admin' ? (
                    <button 
                      onClick={() => toggleTaskStatus(task.id, task.status)}
                      className={`mt-0.5 shrink-0 transition-colors ${
                        task.status === 'done' ? 'text-green-600 hover:text-green-700' : 'text-slate-400 hover:text-blue-600'
                      }`}
                    >
                      {task.status === 'done' ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                    </button>
                  ) : (
                    <div className={`mt-0.5 shrink-0 ${task.status === 'done' ? 'text-green-600' : 'text-slate-400'}`}>
                      {task.status === 'done' ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                    </div>
                  )}
                  <div className="flex-1">
                    <p className={`text-sm ${task.status === 'done' ? 'text-green-800 line-through opacity-70' : 'text-slate-800'} whitespace-pre-wrap leading-relaxed`}>{task.description}</p>
                    <div className="flex items-center justify-between mt-3 text-xs">
                      <span className={`font-medium font-mono ${task.status === 'done' ? 'text-green-600/70' : 'text-slate-500'}`}>
                        Assigned by {task.assignedBy}
                      </span>
                      <div className="flex items-center gap-3">
                        {task.targetDate && (
                           <span className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase ${task.status === 'done' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                             Due: {format(new Date(`${task.targetDate}T12:00:00`), 'MMM d, yyyy')}
                           </span>
                        )}
                        {task.status === 'done' && <span className="font-bold text-green-600 uppercase tracking-widest text-[10px]">Completed</span>}
                        <span className={task.status === 'done' ? 'text-green-600/60' : 'text-slate-400'}>
                          {task.createdAt?.toDate ? format(task.createdAt.toDate(), 'MMM d, yyyy h:mm a') : 'Just now'}
                        </span>
                        {(user?.role === 'manager' && task.assignedByUid === user?.uid) && (
                          <button
                            onClick={() => setTaskToDelete(task.id)}
                            className="text-red-400 hover:text-red-600 p-1 rounded transition-colors ml-1"
                            title="Delete Duty"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {taskToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 mb-4 text-red-600">
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-lg text-slate-900">Delete Duty?</h3>
            </div>
            <p className="text-slate-600 text-sm mb-6">
              Are you sure you want to delete this duty? This action cannot be undone.
            </p>
            <div className="flex gap-3 justify-end">
              <button 
                onClick={cancelDelete}
                className="px-4 py-2 font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                No, Cancel
              </button>
              <button 
                onClick={confirmDeleteAction}
                className="px-4 py-2 font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
