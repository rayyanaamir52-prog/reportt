import React, { useState } from 'react';
import { X, Eye, EyeOff, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { user, changePassword, adminResetPassword } = useAuth();
  
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Admin reset states
  const [targetUserEmail, setTargetUserEmail] = useState('sufyan@wch.local');
  const [adminNewPassword, setAdminNewPassword] = useState('');
  const [adminConfirmPassword, setAdminConfirmPassword] = useState('');
  
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Separating error and success for admin section
  const [adminError, setAdminError] = useState('');
  const [adminSuccess, setAdminSuccess] = useState('');

  if (!isOpen) return null;

  const handleClose = () => {
    if (!isProcessing) {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setAdminNewPassword('');
      setAdminConfirmPassword('');
      setError('');
      setSuccess('');
      setAdminError('');
      setAdminSuccess('');
      onClose();
    }
  };

  const handleBackgroundClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  const validate = () => {
    if (!currentPassword) {
      setError('Current password is required.');
      return false;
    }
    if (!newPassword) {
      setError('New password is required.');
      return false;
    }
    if (!confirmPassword) {
      setError('Confirm new password is required.');
      return false;
    }
    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters long.');
      return false;
    }
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match.');
      return false;
    }
    return true;
  };

  const handleSave = async () => {
    setError('');
    setSuccess('');
    setAdminError('');
    setAdminSuccess('');

    if (!validate()) return;
    
    setIsProcessing(true);

    try {
      await changePassword(currentPassword, newPassword);
      setSuccess('Password updated successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to update password. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAdminReset = async () => {
    setAdminError('');
    setAdminSuccess('');
    setError('');
    setSuccess('');

    if (!adminNewPassword) {
      setAdminError('New password is required.');
      return;
    }
    if (adminNewPassword.length < 6) {
      setAdminError('New password must be at least 6 characters long.');
      return;
    }
    if (adminNewPassword !== adminConfirmPassword) {
      setAdminError('Passwords do not match.');
      return;
    }

    setIsProcessing(true);
    try {
      await adminResetPassword(targetUserEmail, adminNewPassword);
      setAdminSuccess('User password reset successfully!');
      setAdminNewPassword('');
      setAdminConfirmPassword('');
    } catch (err: any) {
      setAdminError(err.message || 'Failed to reset user password.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 animate-in fade-in duration-200"
      onClick={handleBackgroundClick}
    >
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-y-auto max-h-[90vh] animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-blue-50/50 sticky top-0 z-10 backdrop-blur-md">
          <h2 className="text-xl font-bold text-blue-900">Account Settings</h2>
          <button 
            onClick={handleClose}
            disabled={isProcessing}
            className="p-2 text-blue-600 hover:text-blue-900 hover:bg-blue-100 rounded-full transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-8">
          {/* Change Own Password */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-800 border-b border-slate-100 pb-2">Change My Password</h3>
            
            {error && (
              <div className="flex items-center gap-2 p-3 text-sm text-red-600 bg-red-50 rounded-lg border border-red-100">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <p>{error}</p>
              </div>
            )}
            
            {success && (
              <div className="flex items-center gap-2 p-3 text-sm text-green-700 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <p>{success}</p>
              </div>
            )}

            <div className="space-y-4">
              {/* Current Password */}
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700">Current Password</label>
                <div className="relative">
                  <input 
                    type={showCurrentPassword ? "text" : "password"}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    disabled={isProcessing}
                    className="w-full pl-3 pr-10 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow disabled:bg-slate-50 disabled:text-slate-500 text-sm"
                    placeholder="Enter current password"
                  />
                  <button 
                    type="button"
                    disabled={isProcessing}
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* New Password */}
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700">New Password</label>
                <div className="relative">
                  <input 
                    type={showNewPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    disabled={isProcessing}
                    className="w-full pl-3 pr-10 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow disabled:bg-slate-50 disabled:text-slate-500 text-sm"
                    placeholder="Enter new password"
                  />
                  <button 
                    type="button"
                    disabled={isProcessing}
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm New Password */}
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700">Confirm New Password</label>
                <div className="relative">
                  <input 
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    disabled={isProcessing}
                    className="w-full pl-3 pr-10 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow disabled:bg-slate-50 disabled:text-slate-500 text-sm"
                    placeholder="Confirm new password"
                  />
                  <button 
                    type="button"
                    disabled={isProcessing}
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div className="flex justify-end pt-2">
                <button 
                  type="button"
                  onClick={handleSave}
                  disabled={isProcessing}
                  className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    'Save My Password'
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Admin Tools: Reset User Password */}
          {user?.role === 'admin' && (
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h3 className="text-sm font-semibold text-amber-800">Admin Tools: Reset Uses Password</h3>
                <span className="text-[10px] font-bold text-white bg-amber-500 px-2 py-0.5 rounded-full uppercase tracking-widest">Admin Only</span>
              </div>
              
              {adminError && (
                <div className="flex items-center gap-2 p-3 text-sm text-red-600 bg-red-50 rounded-lg border border-red-100">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <p>{adminError}</p>
                </div>
              )}
              
              {adminSuccess && (
                <div className="flex items-center gap-2 p-3 text-sm text-green-700 bg-green-50 rounded-lg border border-green-200">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <p>{adminSuccess}</p>
                </div>
              )}

              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Select User</label>
                  <select
                    value={targetUserEmail}
                    onChange={(e) => setTargetUserEmail(e.target.value)}
                    disabled={isProcessing}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow disabled:bg-slate-50 disabled:text-slate-500 text-sm bg-white"
                  >
                    <option value="sufyan@wch.local">Sir Sufyan (sufyan@wch.local)</option>
                    <option value="ghani@wch.local">Sir Ghani (ghani@wch.local)</option>
                  </select>
                </div>
                
                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">New Password</label>
                  <input 
                    type="password"
                    value={adminNewPassword}
                    onChange={(e) => setAdminNewPassword(e.target.value)}
                    disabled={isProcessing}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow disabled:bg-slate-50 disabled:text-slate-500 text-sm"
                    placeholder="Enter new password for user"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Confirm Password</label>
                  <input 
                    type="password"
                    value={adminConfirmPassword}
                    onChange={(e) => setAdminConfirmPassword(e.target.value)}
                    disabled={isProcessing}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow disabled:bg-slate-50 disabled:text-slate-500 text-sm"
                    placeholder="Confirm new password"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button 
                    type="button"
                    onClick={handleAdminReset}
                    disabled={isProcessing}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-amber-600 rounded-lg hover:bg-amber-700 transition-colors shadow-sm disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Resetting...
                      </>
                    ) : (
                      'Force Reset Password'
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3 rounded-b-2xl">
          <button 
            type="button"
            onClick={handleClose}
            disabled={isProcessing}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-sm disabled:opacity-50 w-full"
          >
            Close Settings
          </button>
        </div>
      </div>
    </div>
  );
}
