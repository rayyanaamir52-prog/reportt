import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Input, Textarea } from './ui/input';
import { Camera, Loader2 } from 'lucide-react';

export function CreateReport() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  
  // Resize and compress image to avoid Firestore 1MB limits
  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        const img = new Image();
        img.src = e.target?.result as string;
        img.onload = () => {
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let { width, height } = img;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.7)); // Compresses to JPEG with 70% quality
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const [formData, setFormData] = useState({
    title: '',
    date: new Date().toISOString().split('T')[0],
    siteName: '',
    siteDescription: '',
    workCompleted: '',
    workers: '',
    remarks: '',
  });

  const [photos, setPhotos] = useState<string[]>([]);
  const [isCompressing, setIsCompressing] = useState(false);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      if (photos.length + e.target.files.length > 5) {
        alert("Maximum 5 photos allowed.");
        return;
      }
      setIsCompressing(true);
      try {
        const newPhotos = await Promise.all(Array.from(e.target.files).map(compressImage));
        setPhotos(prev => [...prev, ...newPhotos]);
      } catch (error) {
        console.error("Error compressing image:", error);
        alert("Failed to process images. Please try again.");
      } finally {
        setIsCompressing(false);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    const reportId = crypto.randomUUID();
    
    try {
      const payload = {
        title: formData.title,
        date: formData.date,
        siteName: formData.siteName,
        siteDescription: formData.siteDescription,
        workCompleted: formData.workCompleted,
        workers: formData.workers,
        remarks: formData.remarks,
        photos: photos,
        status: 'pending',
        authorId: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      await setDoc(doc(db, 'reports', reportId), payload);
      navigate('/');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `reports/${reportId}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <form onSubmit={handleSubmit}>
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-100 bg-slate-50">
             <h3 className="font-bold text-slate-800 text-sm">New Daily Site Report</h3>
          </div>
          <div className="p-5 flex-1 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Report Title</label>
                <Input required value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} placeholder="e.g. Foundation Pour - Phase 1" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</label>
                <Input required type="date" value={formData.date} onChange={e => setFormData({ ...formData, date: e.target.value })} />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Site Name</label>
                <Input required value={formData.siteName} onChange={e => setFormData({ ...formData, siteName: e.target.value })} placeholder="Main Campus Bldg 4" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Workers & Details</label>
                <Input required type="text" value={formData.workers} onChange={e => setFormData({ ...formData, workers: e.target.value })} placeholder="e.g. 5 Masons, 2 Carpenters" />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Site Description</label>
              <Textarea required value={formData.siteDescription} onChange={e => setFormData({ ...formData, siteDescription: e.target.value })} placeholder="Describe the site conditions..." />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Work Completed</label>
              <Textarea required value={formData.workCompleted} onChange={e => setFormData({ ...formData, workCompleted: e.target.value })} placeholder="Details of work executed..." className="min-h-[120px]" />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Remarks & Observations</label>
              <Textarea required value={formData.remarks} onChange={e => setFormData({ ...formData, remarks: e.target.value })} placeholder="Safety notes, delays, etc." />
            </div>

            <div className="pt-4 border-t border-slate-100">
               <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                    <Camera className="w-3 h-3" /> Photos
                  </label>
                  <Input type="file" accept="image/*" multiple onChange={handlePhotoUpload} className="text-xs" disabled={isCompressing || loading} />
                  {photos.length > 0 && <p className="text-xs text-blue-600 font-medium mt-1">{photos.length} photo(s) selected.</p>}
                  {isCompressing && <p className="text-xs font-medium text-amber-600 flex items-center gap-1 mt-1"><Loader2 className="w-3 h-3 animate-spin"/> Processing and compressing images...</p>}
               </div>
            </div>
          </div>
          <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
             <Button variant="ghost" type="button" onClick={() => navigate(-1)} className="text-slate-600 hover:text-slate-900 border border-transparent shadow-none hover:bg-slate-200">Cancel</Button>
             <Button type="submit" disabled={loading} className="bg-blue-600 text-white hover:bg-blue-700 shadow-md">
               {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
               Submit Report
             </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
