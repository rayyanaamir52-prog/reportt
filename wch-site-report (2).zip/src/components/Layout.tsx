import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LayoutDashboard, PlusCircle, Menu, X, LogOut, ListTodo, Settings } from 'lucide-react';
import { format } from 'date-fns';
import { SettingsModal } from './SettingsModal';

export function Layout() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const navigation = [
    { name: 'Dashboard', href: '/', icon: LayoutDashboard },
    ...(user?.role === 'admin' ? [
      { name: 'Reports', href: '/reports/new', icon: PlusCircle },
      { name: 'Duties', href: '/tasks', icon: ListTodo }
    ] : []),
    ...(user?.role === 'manager' ? [{ name: 'Tasks', href: '/tasks', icon: ListTodo }] : []),
  ];

  return (
    <div className="flex h-screen w-full bg-slate-50 text-slate-900 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-900 text-white flex-col hidden md:flex print:hidden">
        <div className="p-6 border-b border-blue-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
              <span className="text-blue-900 font-bold">W</span>
            </div>
            <h1 className="text-xl font-bold tracking-tight">WCH Site Report</h1>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={`flex items-center gap-3 px-4 py-2 rounded-lg text-sm transition-colors ${
                location.pathname === item.href 
                  ? 'bg-blue-800 text-white font-medium' 
                  : 'text-blue-200 hover:bg-blue-800'
              }`}
            >
              <item.icon className="h-4 w-4" />
              {item.name}
            </Link>
          ))}
        </nav>
        
        <div className="p-4 border-t border-blue-800 flex flex-col gap-2">
          <button 
            type="button"
            onClick={() => setIsSettingsOpen(true)} 
            className="flex items-center gap-3 px-4 py-2 w-full text-blue-200 hover:text-white hover:bg-blue-800 rounded-lg transition-colors text-sm"
          >
            <Settings className="w-4 h-4" />
            <span>Settings</span>
          </button>
          <div className="flex items-center gap-3 px-2 flex-1 min-w-0 mt-2">
            <div className="w-10 h-10 bg-blue-700 rounded-full flex shrink-0 border border-blue-600 items-center justify-center font-semibold text-white uppercase">
              {user?.name?.[0] || 'U'}
            </div>
            <div className="overflow-hidden flex-1">
              <p className="text-xs font-bold truncate text-white">{user?.name || 'User'}</p>
              <p className="text-[10px] text-blue-300 capitalize">{user?.role || 'Guest'}</p>
            </div>
            <button onClick={handleLogout} className="p-2 text-blue-300 hover:text-white hover:bg-blue-800 rounded-lg transition-colors ml-auto" title="Log out">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Drawer Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="md:hidden fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
      
      {/* Mobile Menu Drawer */}
      <aside 
        className={`md:hidden fixed inset-y-0 left-0 z-50 w-64 bg-blue-900 text-white flex flex-col transform transition-transform duration-300 ease-in-out ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 border-b border-blue-800 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
              <span className="text-blue-900 font-bold">W</span>
            </div>
            <h1 className="text-xl font-bold tracking-tight">WCH Site Report</h1>
          </div>
          <button 
            type="button"
            onClick={() => setIsMobileMenuOpen(false)}
            className="p-1.5 text-blue-200 hover:text-white rounded hover:bg-blue-800 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm transition-colors ${
                location.pathname === item.href 
                  ? 'bg-blue-800 text-white font-medium' 
                  : 'text-blue-200 hover:bg-blue-800'
              }`}
            >
              <item.icon className="h-4 w-4" />
              {item.name}
            </Link>
          ))}
        </nav>
        
        <div className="p-4 border-t border-blue-800 flex flex-col gap-2">
          <button 
            type="button"
            onClick={() => {
              setIsSettingsOpen(true);
              setIsMobileMenuOpen(false);
            }} 
            className="flex items-center gap-3 px-4 py-2 w-full text-blue-200 hover:text-white hover:bg-blue-800 rounded-lg transition-colors text-sm"
          >
            <Settings className="w-4 h-4" />
            <span>Settings</span>
          </button>
          <div className="flex items-center gap-3 px-2 flex-1 min-w-0 mt-2">
            <div className="w-10 h-10 bg-blue-700 rounded-full flex shrink-0 border border-blue-600 items-center justify-center font-semibold text-white uppercase">
              {user?.name?.[0] || 'U'}
            </div>
            <div className="overflow-hidden flex-1">
              <p className="text-xs font-bold truncate text-white">{user?.name || 'User'}</p>
              <p className="text-[10px] text-blue-300 capitalize">{user?.role || 'Guest'}</p>
            </div>
            <button onClick={handleLogout} className="p-2 text-blue-300 hover:text-white hover:bg-blue-800 rounded-lg transition-colors ml-auto" title="Log out">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Mobile Header */}
        <header className="md:hidden bg-blue-900 text-white p-4 flex justify-between items-center shrink-0 print:hidden">
          <div className="flex items-center gap-3 font-bold tracking-tight">
            <button 
              type="button"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
              className="p-1.5 -ml-1 text-white hover:bg-blue-800 rounded transition-colors focus:outline-none focus:ring-2 focus:ring-white/20"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
            <div className="w-6 h-6 bg-white rounded flex items-center justify-center shrink-0">
              <span className="text-blue-900 font-bold text-xs">W</span>
            </div>
            <span className="truncate">WCH Site Report</span>
          </div>
          <div className="flex items-center">
            {user?.role === 'admin' && location.pathname !== '/reports/new' && (
              <Link 
                to="/reports/new" 
                className="bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs px-3 py-2 rounded-md flex items-center gap-1.5 transition-colors shadow-sm shrink-0"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                New Report
              </Link>
            )}
          </div>
        </header>

        {/* Desktop Header */}
        <header className="hidden md:flex h-16 bg-white border-b border-slate-200 items-center justify-between px-8 shrink-0 print:hidden">
          <h2 className="text-lg font-semibold text-slate-800 capitalize">
             {navigation.find(n => n.href === location.pathname)?.name || 'Overview'}
          </h2>
          <div className="flex items-center gap-4">
             {user?.role === 'admin' && location.pathname !== '/reports/new' && (
               <Link to="/reports/new" className="bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium shadow hover:bg-blue-700 transition">
                 + New Report
               </Link>
             )}
             <div className="h-8 w-[1px] bg-slate-200 hidden md:block"></div>
             <div className="flex items-center gap-2 text-slate-500">
               <span className="text-xs">Today: {format(new Date(), 'MMM d, yyyy')}</span>
             </div>
          </div>
        </header>
        
        <main className="flex-1 p-6 space-y-6 flex flex-col bg-slate-50 overflow-y-auto">
          <div className="max-w-7xl mx-auto w-full flex-1 flex flex-col space-y-6">
            <Outlet />
          </div>
        </main>
      </div>
      
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </div>
  );
}
