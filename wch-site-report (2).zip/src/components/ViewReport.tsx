import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, serverTimestamp, deleteDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from './ui/card';
import { Loader2, ArrowLeft, CheckCircle2, User as UserIcon, Calendar, Camera, Trash2, Download } from 'lucide-react';
import { format } from 'date-fns';
import { jsPDF } from 'jspdf';

export function ViewReport() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [reviewing, setReviewing] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [reviewModal, setReviewModal] = useState<{ open: boolean; reviewerName: string; remarks: string }>({ open: false, reviewerName: '', remarks: '' });
  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    const fetchReport = async () => {
      try {
        const docRef = doc(db, 'reports', id);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          setReport({ id: snap.id, ...snap.data() });
        } else {
          setReport(null);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `reports/${id}`);
      } finally {
        setLoading(false);
      }
    };
    fetchReport();
  }, [id]);

  const openReviewModal = (reviewerName: string) => {
    setReviewModal({ open: true, reviewerName, remarks: '' });
  };

  const confirmReview = async () => {
    if (!id || !user || !reviewModal.reviewerName) return;
    setReviewing(true);
    try {
      const docRef = doc(db, 'reports', id);
      const currentReviewedBy = report.reviewedBy || [];
      const newReviewedBy = [...new Set([...currentReviewedBy, reviewModal.reviewerName])];

      const currentRemarks = report.reviewerRemarks || {};
      const newRemarks = { ...currentRemarks, [reviewModal.reviewerName]: reviewModal.remarks };

      await updateDoc(docRef, {
        status: newReviewedBy.length > 0 ? 'reviewed' : 'pending',
        reviewedBy: newReviewedBy,
        reviewerRemarks: newRemarks,
        reviewDate: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      // updating locally to reflect changes immediately
      setReport((prev: any) => ({
        ...prev,
        status: newReviewedBy.length > 0 ? 'reviewed' : 'pending',
        reviewedBy: newReviewedBy,
        reviewerRemarks: newRemarks,
        reviewDate: new Date()
      }));
      setReviewModal({ open: false, reviewerName: '', remarks: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reports/${id}`);
    } finally {
      setReviewing(false);
    }
  };

  const confirmDelete = async () => {
    try {
      await deleteDoc(doc(db, 'reports', id!));
      navigate('/');
    } catch (error) {
      console.error("Error deleting report:", error);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-blue-500" /></div>;
  }

  if (!report) {
    return <div className="text-center p-12 text-gray-500 font-medium">Report not found.</div>;
  }

  const reviewedByList = report.reviewedBy || [];
  const needGhani = !reviewedByList.includes("Sir Ghani");
  const needSufyan = !reviewedByList.includes("Sir Sufyan");

  const handleDownloadPdf = async () => {
    try {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      pdf.setFontSize(20);
      pdf.setTextColor(30, 58, 138); // blue-900
      pdf.text('WCH Duty Report', 20, 20);

      pdf.setFontSize(10);
      pdf.setTextColor(100, 116, 139); // slate-500
      pdf.text(`ID: #${report.id.substring(0, 12)}`, 20, 28);
      
      pdf.setFontSize(14);
      pdf.setTextColor(15, 23, 42); // slate-900
      pdf.text(`Details: ${report.title}`, 20, 40);

      let yPos = 50;

      const addSection = (title: string, content: string | undefined | null) => {
        if (!content) return;
        
        if (yPos > 260) {
          pdf.addPage();
          yPos = 20;
        }

        pdf.setFontSize(10);
        pdf.setTextColor(148, 163, 184); // slate-400
        pdf.text(title.toUpperCase(), 20, yPos);
        yPos += 6;

        pdf.setFontSize(11);
        pdf.setTextColor(51, 65, 85); // slate-700
        const textLines = pdf.splitTextToSize(content, 170);
        
        if (yPos + (textLines.length * 5) > 280) {
           pdf.addPage();
           yPos = 20;
        }
        
        pdf.text(textLines, 20, yPos);
        yPos += (textLines.length * 6) + 8;
      };

      pdf.setFontSize(10);
      pdf.setTextColor(148, 163, 184); // slate-400
      pdf.text(`Date: ${format(new Date(report.date || Date.now()), 'MMMM d, yyyy')}`, 20, yPos);
      pdf.text(`Site Name: ${report.siteName}`, 100, yPos);
      yPos += 8;
      pdf.text(`Workers: ${report.workers || report.numWorkers}`, 20, yPos);
      
      yPos += 14;

      addSection('Site Description', report.siteDescription);
      addSection('Work Completed', report.workCompleted);
      addSection('Remarks & Observations', report.remarks);

      if (report.reviewerRemarks) {
        Object.entries(report.reviewerRemarks).forEach(([name, remark]) => {
          if (remark) {
            addSection(`Review by ${name}`, remark as string);
          }
        });
      }

      if (report.photos && report.photos.length > 0) {
        if (yPos > 220) {
           pdf.addPage();
           yPos = 20;
        }
        pdf.setFontSize(10);
        pdf.setTextColor(148, 163, 184);
        pdf.text('SITE PHOTOS', 20, yPos);
        yPos += 10;

        let xPos = 20;
        let maxHeightInRow = 0;
        
        for (let i = 0; i < Math.min(report.photos.length, 6); i++) {
          try {
            const imgUrl = report.photos[i];
            const img = new Image();
            img.crossOrigin = "Anonymous";
            await new Promise((resolve, reject) => {
              img.onload = resolve;
              img.onerror = reject;
              img.src = imgUrl;    
            });
            
            const w = 80;
            const ratio = img.height / img.width;
            const h = w * ratio;

            if (xPos + w > 190) {
              xPos = 20;
              yPos += maxHeightInRow + 10;
              maxHeightInRow = 0;
              
              if (yPos > 230) {
                pdf.addPage();
                yPos = 20;
              }
            }

            // Using canvas to ensure we pass base64 since standard images might have CORS limits in jsPDF
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            if(ctx) {
              ctx.drawImage(img, 0, 0);
              const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
              pdf.addImage(dataUrl, 'JPEG', xPos, yPos, w, h);
            }
            
            if (h > maxHeightInRow) maxHeightInRow = h;
            xPos += w + 10;
          } catch(e) {
             console.error("Skipped image", e);
          }
        }
      }

      pdf.save(`WCH_Report_${report.id.substring(0, 8)}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <Button variant="ghost" className="pl-0 gap-2 text-slate-500 hover:text-slate-900 hover:bg-transparent" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" /> Back to Dashboard
        </Button>
        <div className="flex items-center gap-2 flex-wrap">
          {reviewedByList.map((name: string) => (
            <span key={name} className="inline-flex items-center px-2 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded uppercase tracking-wider mb-1 sm:mb-0">
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Reviewed by {name}
            </span>
          ))}
          {report.status === 'pending' && reviewedByList.length === 0 && (
             <span className="inline-flex items-center px-2 py-1 bg-yellow-100 text-yellow-700 text-[10px] font-bold rounded uppercase tracking-wider">
              Pending Review
            </span>
          )}
          <Button variant="outline" size="sm" className="gap-1.5 h-8 ml-auto md:ml-2 rounded transition-colors flex border-slate-200" onClick={handleDownloadPdf}>
            <Download className="w-3.5 h-3.5" /> Download PDF
          </Button>
          <Button variant="outline" size="sm" className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700 gap-1.5 h-8 ml-2 rounded transition-colors" onClick={() => setDeleteConfirmOpen(true)}>
            <Trash2 className="w-3.5 h-3.5" /> Delete
          </Button>
        </div>
      </div>

      <div id="report-content" className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
         <div className="p-4 border-b border-slate-100 bg-slate-50">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
              <div>
                <h3 className="font-bold text-slate-800 text-sm">Report Details: {report.title}</h3>
                <div className="text-[10px] text-slate-500 flex flex-wrap gap-4 mt-1 font-mono tracking-tight">
                   ID: #{report.id.substring(0, 12)}
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 print:hidden">
                {needGhani && (
                  <Button onClick={() => openReviewModal("Sir Ghani")} disabled={reviewing} className="bg-blue-600 text-white rounded text-sm font-bold shadow hover:bg-blue-700 active:scale-[0.98]">
                    {reviewing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                    Review as Sir Ghani
                  </Button>
                )}
                {needSufyan && (
                  <Button onClick={() => openReviewModal("Sir Sufyan")} disabled={reviewing} className="bg-indigo-600 text-white rounded text-sm font-bold shadow hover:bg-indigo-700 active:scale-[0.98]">
                    {reviewing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                    Review as Sir Sufyan
                  </Button>
                )}
              </div>
            </div>
         </div>
         <div className="p-5 flex-1 space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 px-2">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Site Name</p>
                <p className="text-xs text-slate-800 font-medium mt-1">{report.siteName}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</p>
                <p className="text-xs text-slate-800 font-medium mt-1">{format(new Date(report.date), 'MMMM d, yyyy')}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Workers</p>
                <p className="text-xs text-slate-800 font-medium mt-1">{report.workers || report.numWorkers}</p>
              </div>
            </div>

            <div className="px-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Site Description</p>
              <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-4 border border-slate-100 rounded">
                {report.siteDescription}
              </div>
            </div>

            <div className="px-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Work Completed</p>
              <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-4 border border-slate-100 rounded whitespace-pre-wrap">
                {report.workCompleted}
              </div>
            </div>

            <div className="px-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Remarks & Observations</p>
              <div className="text-xs text-slate-700 leading-relaxed bg-blue-50/50 p-4 border border-blue-100/50 rounded whitespace-pre-wrap flex items-start border-l-2 border-l-blue-400">
                {report.remarks}
              </div>
            </div>

            {report.reviewerRemarks && Object.keys(report.reviewerRemarks).length > 0 && (
              <div className="px-2 pt-4 border-t border-slate-100">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Reviewer Remarks</p>
                <div className="space-y-3">
                  {Object.entries(report.reviewerRemarks).map(([name, remark]) => (
                    remark && (
                      <div key={name} className="bg-white border text-sm border-slate-200 rounded p-4 shadow-sm">
                        <p className="font-bold text-slate-800 text-xs mb-1">{name}</p>
                        <p className="text-slate-600 text-xs leading-relaxed whitespace-pre-wrap">{remark as string}</p>
                      </div>
                    )
                  ))}
                </div>
              </div>
            )}

            {(report.photos?.length > 0) && (
              <div className="pt-6 border-t border-slate-100 px-2">
                 {report.photos?.length > 0 && (
                   <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Site Photos</p>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {report.photos.map((photo: string, i: number) => (
                           <img key={i} src={photo} alt={`Report Photo ${i+1}`} className="aspect-square w-full object-cover rounded border border-slate-200 cursor-pointer hover:opacity-90 transition-opacity" onClick={() => setFullscreenImage(photo)} />
                        ))}
                      </div>
                   </div>
                 )}
              </div>
            )}
         </div>
      </div>

      {deleteConfirmOpen && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirmOpen(false)}>
          <div className="bg-white rounded-xl shadow-lg max-w-sm w-full p-6 animate-in fade-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Report</h3>
            <p className="text-sm text-slate-500 mb-6">Are you sure you want to delete this report? This action cannot be undone.</p>
            <div className="flex justify-end gap-3 tracking-tight">
              <button className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors" onClick={() => setDeleteConfirmOpen(false)}>Cancel</button>
              <button className="px-4 py-2 text-sm font-medium bg-red-600 text-white hover:bg-red-700 rounded shadow-sm transition-colors" onClick={confirmDelete}>Delete</button>
            </div>
          </div>
        </div>
      )}

      {reviewModal.open && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" onClick={() => setReviewModal({ open: false, reviewerName: '', remarks: '' })}>
          <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Review as {reviewModal.reviewerName}</h3>
            <p className="text-sm text-slate-500 mb-4">Please add any remarks or observations for this report.</p>
            <textarea 
              className="w-full text-sm p-3 border border-slate-200 rounded-lg min-h-[120px] focus:outline-none focus:ring-2 focus:ring-blue-500 mb-6"
              placeholder="Enter your remarks here..."
              value={reviewModal.remarks}
              onChange={(e) => setReviewModal(r => ({ ...r, remarks: e.target.value }))}
            />
            <div className="flex justify-end gap-3 tracking-tight">
              <button className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors" onClick={() => setReviewModal({ open: false, reviewerName: '', remarks: '' })}>Cancel</button>
              <button className="px-4 py-2 text-sm font-medium bg-blue-600 text-white hover:bg-blue-700 rounded shadow-sm transition-colors" onClick={confirmReview} disabled={reviewing}>
                {reviewing ? 'Submitting...' : 'Submit Review'}
              </button>
            </div>
          </div>
        </div>
      )}

      {fullscreenImage && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4" onClick={() => setFullscreenImage(null)}>
          <div className="relative max-w-5xl w-full h-full flex flex-col items-center justify-center animate-in fade-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <button className="absolute top-4 right-4 text-white hover:text-slate-300 p-2" onClick={() => setFullscreenImage(null)}>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <img src={fullscreenImage} alt="Fullscreen" className="max-w-full max-h-[90vh] object-contain" />
          </div>
        </div>
      )}
    </div>
  );
}
