import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot, deleteDoc, doc, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Briefcase } from 'lucide-react';

export function Dashboard() {
  const [reports, setReports] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const { user } = useAuth();
  const navigate = useNavigate();

  const confirmDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteDoc(doc(db, 'reports', deleteConfirmId));
      setDeleteConfirmId(null);
    } catch (error) {
      console.error("Error deleting report:", error);
    }
  };

  useEffect(() => {
    if (!user || user.role === 'pending') return;

    // Fetch reports
    const qReports = query(
      collection(db, 'reports'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeReports = onSnapshot(qReports, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReports(data);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reports');
      setLoading(false);
    });

    // Fetch tasks
    const qTasks = query(
      collection(db, 'tasks'),
      orderBy('createdAt', 'desc'),
      limit(5)
    );
    const unsubscribeTasks = onSnapshot(qTasks, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => console.error(error));

    return () => {
      unsubscribeReports();
      unsubscribeTasks();
    };
  }, [user]);

  if (loading) {
    return <div className="animate-pulse space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[1,2,3,4].map(i => <div key={i} className="h-24 bg-slate-200 rounded-xl"></div>)}
      </div>
    </div>;
  }

  const pendingCount = reports.filter(r => r.status === 'pending').length;
  const reviewedCount = reports.filter(r => r.status === 'reviewed').length;

  return (
    <div className="flex-1 flex flex-col space-y-6">
      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-shrink-0">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Total Reports</p>
          <p className="text-2xl font-bold text-slate-800 mt-1">{reports.length}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-xs text-blue-600 font-medium uppercase tracking-wider">Pending Review</p>
          <p className="text-2xl font-bold text-slate-800 mt-1">{pendingCount}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm border-l-4 border-l-green-500">
          <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Reviewed</p>
          <p className="text-2xl font-bold text-slate-800 mt-1">{reviewedCount}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Active Sites</p>
          <p className="text-2xl font-bold text-slate-800 mt-1">
            {new Set(reports.map(r => r.siteName)).size}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
        
        {/* Main Content (List) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col min-h-0 overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-white">
            <h3 className="font-bold text-slate-800">Recent Activity</h3>
          </div>
          
          <div className="flex-1 overflow-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 sticky top-0 z-10">
                <tr>
                  <th className="px-4 py-3 text-[11px] font-bold uppercase tracking-widest whitespace-nowrap">Title / ID</th>
                  <th className="px-4 py-3 text-[11px] font-bold uppercase tracking-widest">Site Name</th>
                  <th className="px-4 py-3 text-[11px] font-bold uppercase tracking-widest whitespace-nowrap">Date</th>
                  <th className="px-4 py-3 text-[11px] font-bold uppercase tracking-widest">Status</th>
                  <th className="px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reports.slice(0, 10).map((report, idx) => (
                  <tr 
                    key={report.id} 
                    onClick={() => navigate(`/reports/${report.id}`)}
                    className={`cursor-pointer transition-colors ${
                      report.status === 'reviewed' && idx % 2 === 1 
                        ? 'bg-blue-50/30' 
                        : 'hover:bg-blue-50'
                    }`}
                  >
                    <td className={`px-4 py-3 ${report.status === 'reviewed' && idx % 2 === 1 ? 'border-l-4 border-l-blue-600' : ''}`}>
                      <p className="text-sm font-semibold text-slate-900 truncate max-w-[150px]">{report.title}</p>
                      <p className="text-[10px] text-slate-400 font-mono tracking-tight mt-0.5">#{report.id.substring(0, 8)}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600 truncate max-w-[120px]">{report.siteName}</td>
                    <td className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">{format(new Date(report.date), 'MMM d, yyyy')}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {report.status === 'pending' ? (
                         <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-[10px] font-bold rounded uppercase tracking-wider">Pending</span>
                      ) : (
                         <span className="px-2 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded uppercase tracking-wider">Reviewed</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {user?.role === 'admin' && (
                        <button 
                          onClick={(e) => { e.stopPropagation(); setDeleteConfirmId(report.id); }} 
                          className="text-slate-400 hover:text-red-600 transition-colors p-1"
                          title="Delete Report"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {reports.length === 0 && (
                  <tr>
                     <td colSpan={5} className="px-4 py-8 text-center text-sm text-slate-500">No reports found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tasks View for Dashboard */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col min-h-0 overflow-hidden">
           <div className="p-4 border-b border-slate-100 flex items-center gap-2 bg-white sticky top-0 z-10">
              <Briefcase className="w-4 h-4 text-blue-600" />
              <h3 className="font-bold text-slate-800">Assigned Duties</h3>
           </div>
           <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              {tasks.length === 0 ? (
                <div className="text-center py-6 text-sm text-slate-500">No duties assigned.</div>
              ) : (
                tasks.map(task => (
                  <div 
                    key={task.id} 
                    className={`border rounded-lg p-3 shadow-sm transition-colors ${
                      task.status === 'done' 
                        ? 'bg-green-50 border-green-100' 
                        : 'bg-slate-50 border-slate-100'
                    }`}
                  >
                    <p className={`text-sm whitespace-pre-wrap ${task.status === 'done' ? 'text-green-800 line-through opacity-70' : 'text-slate-800'}`}>
                      {task.description}
                    </p>
                    <div className="flex items-center justify-between mt-3">
                      <span className={`text-[10px] font-bold uppercase tracking-widest ${task.status === 'done' ? 'text-green-600/70' : 'text-slate-500'}`}>
                        {task.assignedBy}
                      </span>
                      <div className="flex items-center gap-2">
                        {task.status === 'done' && <span className="text-[10px] font-bold text-green-600 uppercase tracking-widest">Done</span>}
                        <span className={`text-xs ${task.status === 'done' ? 'text-green-600/50' : 'text-slate-400'}`}>
                          {task.createdAt?.toDate ? format(task.createdAt.toDate(), 'MMM d') : ''}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
           </div>
        </div>

      </div>

      {deleteConfirmId && (
        <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirmId(null)}>
          <div className="bg-white rounded-xl shadow-lg max-w-sm w-full p-6 animate-in fade-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Report</h3>
            <p className="text-sm text-slate-500 mb-6">Are you sure you want to delete this report? This action cannot be undone.</p>
            <div className="flex justify-end gap-3 tracking-tight">
              <button className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors" onClick={() => setDeleteConfirmId(null)}>Cancel</button>
              <button className="px-4 py-2 text-sm font-medium bg-red-600 text-white hover:bg-red-700 rounded shadow-sm transition-colors" onClick={confirmDelete}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
